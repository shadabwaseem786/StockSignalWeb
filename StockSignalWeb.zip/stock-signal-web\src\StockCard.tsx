﻿import React, { useEffect, useState } from 'react';
import { fetchCandles, Candle } from './api';
import { emaCrossoverSignals, Signal } from './indicators';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
interface Props { symbol: string; }
export const StockCard: React.FC<Props> = ({ symbol }) => {
  const [candles, setCandles] = useState<Candle[]>([]);
  const [signal, setSignal] = useState<Signal|null>(null);
  const fetchData = async () => { const data = await fetchCandles(symbol); setCandles(data); setSignal(emaCrossoverSignals(data.map(c=>c.close))); };
  useEffect(()=>{ fetchData(); const interval = setInterval(fetchData,60000); return ()=>clearInterval(interval); },[symbol]);
  return (
    <div style={{border:'1px solid #ccc', margin:8, padding:12, borderRadius:8}}>
      <h3>{symbol}</h3>
      <p>{signal ? ${signal.type} () : 'No Signal'}</p>
      <ResponsiveContainer width='100%' height={80}>
        <LineChart data={candles}>
          <Line dataKey='close' stroke={signal?.type==='BUY'?'green':signal?.type==='SELL'?'red':'gray'} dot={false}/>
          <XAxis dataKey='datetime' hide/>
          <YAxis domain={['auto','auto']} hide/>
          <Tooltip/>
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};
