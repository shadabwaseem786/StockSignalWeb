﻿import axios from 'axios';
const API_KEY = '507b2e5a19454aa48891d4440169a3c0';
const BASE_URL = 'https://api.twelvedata.com/time_series';
export interface Candle { datetime:string; open:number; high:number; low:number; close:number; volume:number; }
export async function fetchCandles(symbol:string, interval:string='15min', outputsize:number=100):Promise<Candle[]>{
  const res = await axios.get(BASE_URL, { params:{symbol, interval, outputsize, apikey:API_KEY} });
  return res.data.values.reverse();
}
