﻿import React from 'react';
import { StockCard } from './StockCard';
const symbols=['INFY.NSE','RELIANCE.NSE','TCS.NSE'];
function App(){ return <div style={{padding:16}}>{symbols.map(s=><StockCard key={s} symbol={s}/>)}</div>; }
export default App;
