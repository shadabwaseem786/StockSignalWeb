﻿export interface Signal { type:'BUY'|'SELL'; reason:string; }
export function ema(values:number[], period:number):number[]{
  if(values.length<period) return Array(values.length).fill(NaN);
  const k = 2/(period+1); const out = Array(values.length).fill(NaN);
  out[period-1] = values.slice(0, period).reduce((a,b)=>a+b,0)/period;
  for(let i=period;i<values.length;i++){ out[i]=values[i]*k + out[i-1]*(1-k); }
  return out;
}
export function emaCrossoverSignals(closes:number[], fast=12, slow=26):Signal|null{
  const f=ema(closes,fast); const s=ema(closes,slow); const i=closes.length-1;
  if(i<slow) return null;
  if(f[i-1]<=s[i-1]&&f[i]>s[i]) return {type:'BUY', reason:EMA crossed above EMA};
  if(f[i-1]>=s[i-1]&&f[i]<s[i]) return {type:'SELL', reason:EMA crossed below EMA};
  return null;
}
